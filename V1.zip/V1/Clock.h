#ifndef Clock_H
#define Clock_H

// Functions prototypes
void Clock_Update();
int Clock_GetTime();

#endif
